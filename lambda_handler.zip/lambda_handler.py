import json
import urllib3
import os

#import base64
#import hashlib
#import hmac
#import boto3
#from botocore.exceptions import ClientError


HMAC_KEY = os.getenv("HMAC_KEY", None)
REGION = os.getenv("REGION", None)
REGION = os.getenv("EST_RUN_HOURS", 0)

try:
    print(hmac_key)
except:
    print(Exception)
        
        
def lambda_handler(event, context):
    #print(f"raw event: {event}")
    try:
        signature = event['headers']['x-tfc-task-signature']
        print(f"The TFC task signature is:  {signature}")
        payload = json.loads(event['body'])
        print(f" The body from the Run task is:----  {payload}")
        callback_url = payload['task_result_callback_url']
        access_token = payload['access_token']
        message = "cool"
        
    except:
        print(Exception)
        return {"statusCode": 400, "body": json.dumps(Exception)}
    
    try:
        tfc_callback(callback_url,access_token,message)
    except:
        print(Exception)
        return {"statusCode": 400, "body": json.dumps(Exception)}
    
    
    return {
        "statusCode": 200,
        "body": json.dumps("Cost estimation goes here!")
    }



def validate_hash(sig):
    #do this later
    return 1
    
    
def tfc_callback(url,token,message):
    http = urllib3.PoolManager()
    #headers = urllib3.util.make_headers(basic_auth=token,'Content-Type'='Content-Type')
    encoded_data = json.dumps({"data": {"type": "task-results", "attributes": {"status":"passed", "message": message}}})
    r = http.request('PATCH', 
        url, 
        headers = {'Content-Type': 'application/vnd.api+json', 'Authorization': f'Bearer {token}'},
        body = encoded_data)
    return 1
    
    